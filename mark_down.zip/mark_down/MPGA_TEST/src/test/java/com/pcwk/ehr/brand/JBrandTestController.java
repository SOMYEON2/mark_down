package com.pcwk.ehr.brand;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.pcwk.ehr.MessageVO;
import com.pcwk.ehr.SearchVO;

public class JBrandTestController {
	final Logger  LOG = LoggerFactory.getLogger(getClass());
	
	@Autowired
	WebApplicationContext webApplicationContext;
	
	MockMvc  mockMvc;	
	
	BrandVO brand01;
	BrandVO brand02;
	BrandVO brand03;
	
	SearchVO search01;
	
	@Autowired
	BrandDao dao;
	
	
	@Before
	public void setUp() throws Exception {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
		
		brand01 = new BrandVO("B_01_01", "qwer", "www.chicken01.com","맛있음닭","교촌치킨","",1);
		brand02 = new BrandVO("B_01_02", "zxcv", "www.chicken02.com","신선하닭","땅땅치킨","",2);
		brand03 = new BrandVO("B_01_03", "asdf", "www.chicken03.com","최고임닭","페리카나","",3);
		
		search01 = new SearchVO();
		search01.setPageNum(1);
		search01.setPageSize(10);
		
	}
		

	@Test
	@Ignore
	public void doRetrieve() throws Exception {
        search01.setSearchDiv("10");
        search01.setSearchWord("j_hr000000");
		
		//param,url
		MockHttpServletRequestBuilder createMessage =
				MockMvcRequestBuilders.get("/brand/doRetrieve.do")
				 .param("searchDiv",   search01.getSearchDiv())
				 .param("searchWord",  search01.getSearchWord())
				 .param("pageSize",    String.valueOf(search01.getPageSize()))
				 .param("pageNum",     String.valueOf(search01.getPageNum()));
				 
		ResultActions    resultActions = mockMvc.perform(createMessage)
                .andExpect(status().is2xxSuccessful());		 
		String result = resultActions.andDo(print())
                .andReturn()
                .getResponse().getContentAsString();
		LOG.debug("=====================================");
		LOG.debug("=result="+result);
		LOG.debug("=====================================");		
		
		Gson gson=new Gson();
		List<BrandVO> list=gson.fromJson(result, new TypeToken<List<BrandVO>>(){}.getType());
		
		for(BrandVO vo :list) {
			LOG.debug("=vo="+vo);
		}
		
		assertThat(list.size(), is(10));
	}
	

	@Test
	//@Ignore
	public void doUpdate() throws Exception {
		//전체삭제
		dao.deleteAll();
		//단건 입력
		dao.doInsert(brand01);
		//단건 조회
		BrandVO vsBrand = dao.doSelectOne(brand01);
		
		String upStr = "_U";
		//수정
		vsBrand.setbCode(vsBrand.getbName()+upStr);
		vsBrand.setbLogoImg(vsBrand.getbLogoImg()+upStr);
		vsBrand.setbUrl(vsBrand.getbUrl()+upStr);
		vsBrand.setbItr(vsBrand.getbItr()+upStr);
		vsBrand.setbName(vsBrand.getbName());
		vsBrand.setRegNum(vsBrand.getRegNum()+10);
		
		
		MockHttpServletRequestBuilder createMessage =
				MockMvcRequestBuilders.post("/brand/doUpdate.do")
				 .param("bCode",				vsBrand.getbCode())
				 .param("bLogoImg",				vsBrand.getbLogoImg())
				 .param("bUrl",					vsBrand.getbUrl())
				 .param("bItr",					vsBrand.getbItr())
				 .param("bName",    			vsBrand.getbName())
				 .param("regNum",String.valueOf(vsBrand.getRegNum()));	
		ResultActions    resultActions = mockMvc.perform(createMessage)
				                      .andExpect(status().is2xxSuccessful());
		
		String result = resultActions.andDo(print())
		                .andReturn()
		                .getResponse().getContentAsString();
		LOG.debug("=====================================");
		LOG.debug("=result="+result);
		LOG.debug("=====================================");	
				
		Gson gson=new Gson();
		
		MessageVO message = gson.fromJson(result, MessageVO.class);
		
		assertThat(message.getMsgId(), is("1"));
		assertThat(message.getMsgContents(), is("수정 되었습니다."));
		
		BrandVO getUpdatebrand = dao.doSelectOne(vsBrand);
		this.isSamebrand(vsBrand, getUpdatebrand);
	}

	
	
	@Test
	//@Ignore
	private int doInsert(BrandVO brand) throws Exception {
		MockHttpServletRequestBuilder createMessage =
				MockMvcRequestBuilders.post("/brand/doInsert.do")
				 .param("bCode",		brand.getbCode())
				 .param("bLogoImg",		brand.getbLogoImg())
				 .param("bUrl",			brand.getbUrl())
				 .param("bItr",			brand.getbItr())
				 .param("bName",		brand.getbName())
				 .param("regNum",		String.valueOf(brand.getRegNum()));
		
		@SuppressWarnings("deprecation")
		ResultActions  resultActions = mockMvc.perform(createMessage)
		                               .andExpect(status().is2xxSuccessful())
		                               .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_UTF8));
		
		String result = resultActions.andDo(print())
				      .andReturn()
				      .getResponse().getContentAsString();
		
		Gson gson =new Gson();
		MessageVO message = gson.fromJson(result, MessageVO.class);
		LOG.debug("=====================================");
		LOG.debug("=message="+message);
		LOG.debug("=====================================");
		
		assertThat(message.getMsgId(), is("1"));
		assertThat(message.getMsgContents(), is("등록 되었습니다."));
		
		return Integer.valueOf(message.getMsgId());
	}
	
	
	
	@Test
	//@Ignore
	private BrandVO doSelectOne(BrandVO brand) throws Exception {
		MockHttpServletRequestBuilder createMessage =
				MockMvcRequestBuilders.get("/brand/doSelectOne.do")
				 .param("bCode", brand.getbCode());
		
		ResultActions  resultActions = this.mockMvc.perform(createMessage)
				                       .andExpect(status().is2xxSuccessful() );
				                       
		String result = resultActions.andDo(print())
				      .andReturn()
				      .getResponse().getContentAsString();
		
		Gson gson=new Gson();
		
		BrandVO outVO =gson.fromJson(result, BrandVO.class);
		LOG.debug("==========================");
		LOG.debug("=result="+result);
		LOG.debug("=outVO="+outVO);
		LOG.debug("==========================");
		isSamebrand(outVO, brand01);
		
		return outVO;
	}
	
	
	@Test
	//@Ignore
	private int doDelete(BrandVO brand) throws Exception {
		MockHttpServletRequestBuilder createMessage =
						MockMvcRequestBuilders.get("/brand/doDelete.do")
						 .param("bCode", brand.getbCode());	
		ResultActions  resultActions = this.mockMvc.perform(createMessage)
						               .andExpect( status().is2xxSuccessful() );
		String result = resultActions.andDo(print())
				      .andReturn()
				      .getResponse().getContentAsString();
		
		Gson gson=new Gson();
		MessageVO message = gson.fromJson(result,MessageVO.class);
		
		LOG.debug("==========================");
		LOG.debug("=result="+result);
		LOG.debug("=message="+message);
		LOG.debug("==========================");	
		
		assertThat(message.getMsgId(), is("1"));
		assertThat(message.getMsgContents(), is("삭제 되었습니다."));
		
		return Integer.valueOf(message.getMsgId());
	}
	
	@Test
	//@Ignore
	public void addAndGet() throws Exception {
		dao.deleteAll();
		
		doInsert(brand01);
		
		doDelete(brand01);
		
		int flag = doInsert(brand01);
		assertThat(flag, is(1));
		
		BrandVO vsBrand01 = doSelectOne(brand01);
		
		isSamebrand(vsBrand01, brand01);
	}
	
	
	public void isSamebrand(BrandVO outVO, BrandVO brand) {
		assertThat(outVO.getbCode(), 	is(brand.getbCode()));
		assertThat(outVO.getbLogoImg(), is(brand.getbLogoImg()));
		assertThat(outVO.getbUrl(), 	is(brand.getbUrl()));
		assertThat(outVO.getbItr(), 	is(brand.getbItr()));
		assertThat(outVO.getbName(), 	is(brand.getbName()));
		assertThat(outVO.getRegNum(), 	is(brand.getRegNum()));
		
	}
	
	
	@Test
	public void beans() {
		LOG.debug("webApplicationContext"+webApplicationContext);
		assertThat(webApplicationContext, is(notNullValue()));
	}
	
}
